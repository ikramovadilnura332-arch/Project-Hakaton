// Email yuborish (parolni tiklash uchun). SMTP .env orqali sozlanadi.
const nodemailer = require('nodemailer');

const isConfigured = () => !!process.env.SMTP_HOST;
let transport = null;

function getTransport() {
  if (!transport) {
    const port = Number(process.env.SMTP_PORT || 587);
    transport = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port,
      secure: process.env.SMTP_SECURE ? process.env.SMTP_SECURE === 'true' : port === 465,
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS || '' } : undefined,
    });
  }
  return transport;
}

async function sendMail({ to, subject, text }) {
  if (!isConfigured()) {
    // Faqat rivojlanish rejimida (production'da server.js bunga yo'l qo'ymaydi)
    console.log(`\n[EMAIL yuborilmadi: SMTP sozlanmagan]\nKimga: ${to}\nMavzu: ${subject}\n${text}\n`);
    return;
  }
  await getTransport().sendMail({
    from: process.env.SMTP_FROM || 'Finodex <no-reply@localhost>',
    to,
    subject,
    text,
  });
}

module.exports = { sendMail, isConfigured };
