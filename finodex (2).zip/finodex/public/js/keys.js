// Klaviatura bilan qulay ishlash + parolni ko'rsatish tugmasi
(function () {
  // ---------- Enter: keyingi maydonga o'tadi, oxirgisida formani yuboradi ----------
  // Shift+Enter — oldingi maydonga qaytadi.
  const TEXTLIKE = ['text', 'email', 'password', 'search', 'tel', 'url', 'number'];

  function stops(form) {
    const seen = new Set();
    const out = [];
    form.querySelectorAll('input, select, textarea').forEach((el) => {
      if (el.disabled || el.type === 'hidden' || el.type === 'file') return;
      if (el.getClientRects().length === 0) return; // ko'rinmaydigan maydon
      if (el.type === 'radio') {
        if (seen.has(el.name)) return;
        seen.add(el.name);
        out.push(form.querySelector(`input[type="radio"][name="${el.name}"]:checked`) || el);
        return;
      }
      out.push(el);
    });
    return out;
  }

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.isComposing || e.ctrlKey || e.altKey || e.metaKey) return;
    const el = e.target;
    if (!el || !el.matches || !el.matches('input, select')) return;
    if (['button', 'submit', 'reset', 'checkbox', 'file', 'image'].includes(el.type)) return;
    const form = el.form;
    if (!form) return;

    const list = stops(form);
    const idx = list.findIndex((x) => x === el || (el.type === 'radio' && x.type === 'radio' && x.name === el.name));
    if (idx < 0) return;

    e.preventDefault();
    const target = e.shiftKey ? list[idx - 1] : list[idx + 1];
    if (target) {
      target.focus();
      if (TEXTLIKE.includes(target.type)) { try { target.select(); } catch { /* ba'zi turlarda mumkin emas */ } }
    } else if (!e.shiftKey) {
      const btn = form.querySelector('button[type="submit"], input[type="submit"]');
      if (btn && btn.disabled) return; // yuborilyapti — ikki marta yubormaymiz
      form.requestSubmit(btn || undefined);
    }
  });

  // ---------- Parolni ko'rsatish / yashirish ----------
  const EYE = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  const EYE_OFF = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.9 17.9A10.9 10.9 0 0 1 12 19c-7 0-11-7-11-7a19.8 19.8 0 0 1 5.1-5.9M9.9 4.2A10.6 10.6 0 0 1 12 4c7 0 11 7 11 7a19.9 19.9 0 0 1-3.2 4.2M1 1l22 22"/><path d="M14.1 14.1a3 3 0 1 1-4.2-4.2"/></svg>';

  function enhancePassword(input) {
    if (input.dataset.pw) return;
    input.dataset.pw = '1';

    const hadFocus = document.activeElement === input;
    const wrap = document.createElement('div');
    wrap.className = 'pw-wrap';
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);
    if (hadFocus) input.focus(); // elementni ko'chirganda autofocus yo'qolmasin

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pw-toggle';
    btn.setAttribute('aria-pressed', 'false');
    btn.setAttribute('aria-label', "Parolni ko'rsatish");
    btn.title = "Parolni ko'rsatish";
    btn.innerHTML = EYE;
    wrap.appendChild(btn);

    const caps = document.createElement('span');
    caps.className = 'hint caps';
    caps.textContent = 'Caps Lock yoqilgan';
    caps.hidden = true;
    wrap.after(caps);

    btn.addEventListener('click', () => {
      const show = input.type === 'password';
      const start = input.selectionStart;
      const end = input.selectionEnd;
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-pressed', String(show));
      const label = show ? 'Parolni yashirish' : "Parolni ko'rsatish";
      btn.setAttribute('aria-label', label);
      btn.title = label;
      btn.innerHTML = show ? EYE_OFF : EYE;
      input.focus();
      try { input.setSelectionRange(start, end); } catch { /* e'tiborsiz */ }
    });

    input.addEventListener('keydown', (e) => { if (e.getModifierState) caps.hidden = !e.getModifierState('CapsLock'); });
    input.addEventListener('keyup', (e) => { if (e.getModifierState) caps.hidden = !e.getModifierState('CapsLock'); });
    input.addEventListener('blur', () => { caps.hidden = true; });
  }

  document.querySelectorAll('input[type="password"]').forEach(enhancePassword);
})();
