// Bildirishnomalar: qo'ng'iroqcha, ro'yxat va brauzer bildirishnomasi
(function () {
  const host = document.querySelector('.app-user');
  if (!host) return;

  const SEEN_KEY = 'fd_notif_seen';
  let seen = null;
  try { const v = localStorage.getItem(SEEN_KEY); seen = v === null ? null : Number(v); } catch { /* ruxsat yo'q */ }

  const wrap = document.createElement('div');
  wrap.className = 'notif';
  wrap.innerHTML = `
    <button class="bell" id="bell" type="button" aria-label="Bildirishnomalar" aria-expanded="false" aria-controls="notif-panel">
      <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>
      <span class="bell-badge" id="bell-badge" hidden>0</span>
    </button>
    <div class="notif-panel" id="notif-panel" hidden>
      <div class="notif-head">
        <strong>Bildirishnomalar</strong>
        <button class="btn-link" id="notif-perm" type="button" hidden>Brauzerda yoqish</button>
      </div>
      <div id="notif-list" class="notif-list"></div>
    </div>`;
  host.insertBefore(wrap, host.firstChild);

  const bell = wrap.querySelector('#bell');
  const badge = wrap.querySelector('#bell-badge');
  const panel = wrap.querySelector('#notif-panel');
  const list = wrap.querySelector('#notif-list');
  const permBtn = wrap.querySelector('#notif-perm');

  const ago = (s) => {
    const t = Date.parse(s.replace(' ', 'T') + 'Z');
    const m = Math.max(0, Math.round((Date.now() - t) / 60000));
    if (m < 1) return 'hozir';
    if (m < 60) return `${m} daqiqa oldin`;
    if (m < 1440) return `${Math.round(m / 60)} soat oldin`;
    return `${Math.round(m / 1440)} kun oldin`;
  };

  function updatePermUi() {
    permBtn.hidden = !('Notification' in window) || Notification.permission !== 'default';
  }

  function render(items, unread) {
    badge.hidden = unread === 0;
    badge.textContent = unread > 9 ? '9+' : String(unread);
    list.innerHTML = items.length
      ? items.map((n) => `
          <div class="notif-item ${esc(n.level)}${n.is_read ? '' : ' unread'}">
            <div class="notif-title">${esc(n.title)}</div>
            <div class="notif-text">${esc(n.text)}</div>
            <div class="notif-time">${esc(ago(n.created_at))}</div>
          </div>`).join('')
      : `<div class="notif-empty">Hozircha bildirishnoma yo'q. Prognozda xavf paydo bo'lsa, shu yerda va brauzerda ko'rasiz.</div>`;
  }

  function browserNotify(n) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    try { new Notification(n.title, { body: n.text.slice(0, 180), tag: 'finodex-' + n.id }); } catch { /* ba'zi brauzerlar */ }
  }

  async function load() {
    let data;
    try { data = await api('/api/notifications'); } catch { return; }
    const items = data.notifications;
    const maxId = items.reduce((m, n) => Math.max(m, n.id), 0);
    if (seen === null) {
      seen = maxId; // birinchi yuklashda eskilarini qayta ko'rsatmaymiz
    } else {
      const fresh = items.filter((n) => n.id > seen && !n.is_read).reverse();
      fresh.forEach((n) => { browserNotify(n); toast(n.title, n.level === 'danger'); });
      if (maxId > seen) seen = maxId;
    }
    try { localStorage.setItem(SEEN_KEY, String(seen)); } catch { /* ruxsat yo'q */ }
    render(items, panel.hidden ? data.unread : 0);
  }
  window.loadNotifications = load;

  function closePanel() { panel.hidden = true; bell.setAttribute('aria-expanded', 'false'); }

  bell.addEventListener('click', async () => {
    const opening = panel.hidden;
    panel.hidden = !opening;
    bell.setAttribute('aria-expanded', String(opening));
    if (opening) {
      updatePermUi();
      await load();
      try { await api('/api/notifications/read-all', { method: 'POST' }); badge.hidden = true; } catch { /* keyingi safar */ }
    }
  });
  document.addEventListener('click', (e) => { if (!wrap.contains(e.target)) closePanel(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePanel(); });

  permBtn.addEventListener('click', async () => {
    try { await Notification.requestPermission(); } catch { /* eski brauzer */ }
    updatePermUi();
    if (Notification.permission === 'granted') toast('Brauzer bildirishnomalari yoqildi');
  });

  updatePermUi();
  load();
  setInterval(load, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) load(); });
})();
