// Finodex AI chat: har doim javob beradigan yordamchi
(function () {
  const fab = document.createElement('button');
  fab.className = 'chat-fab';
  fab.type = 'button';
  fab.setAttribute('aria-label', 'AI yordamchini ochish');
  fab.setAttribute('aria-expanded', 'false');
  fab.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><span>AI yordamchi</span>';

  const panel = document.createElement('section');
  panel.className = 'chat-panel';
  panel.hidden = true;
  panel.setAttribute('aria-label', 'Finodex AI yordamchi');
  panel.innerHTML = `
    <header class="chat-head">
      <div><strong>Finodex AI</strong><div class="chat-status" id="chat-status">Onlayn</div></div>
      <div>
        <button class="btn-link" id="chat-clear" type="button">Tozalash</button>
        <button class="chat-close" id="chat-close" type="button" aria-label="Yopish">×</button>
      </div>
    </header>
    <div class="chat-log" id="chat-log" role="log" aria-live="polite"></div>
    <div class="chat-chips" id="chat-chips"></div>
    <form class="chat-form" id="chat-form" autocomplete="off">
      <input id="chat-input" maxlength="1000" placeholder="Savolingizni yozing…" aria-label="Savol">
      <button class="btn btn-primary btn-small" type="submit">Yuborish</button>
    </form>`;
  document.body.append(fab, panel);

  const log = panel.querySelector('#chat-log');
  const input = panel.querySelector('#chat-input');
  const form = panel.querySelector('#chat-form');
  const chips = panel.querySelector('#chat-chips');
  const status = panel.querySelector('#chat-status');
  let loaded = false;
  let busy = false;

  const QUESTIONS = ['Kassa uzilishi bormi?', 'Qoldiq necha kunga yetadi?', "Xarajatni qanday kamaytiraman?", 'Keyingi oy savdo qanday bo\'ladi?'];
  const GREETING = "Assalomu alaykum! Men Finodex AI yordamchisiman. Kassa, prognoz, savdo va xarajatlaringiz haqida istalgan vaqt so'rang — sizning ma'lumotingiz asosida javob beraman.";

  function add(role, text) {
    const el = document.createElement('div');
    el.className = 'chat-msg ' + (role === 'user' ? 'user' : 'bot');
    el.textContent = text;
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
    return el;
  }

  chips.innerHTML = QUESTIONS.map((q) => `<button type="button" class="chip">${esc(q)}</button>`).join('');
  chips.addEventListener('click', (e) => {
    const b = e.target.closest('.chip');
    if (b) send(b.textContent);
  });

  async function open() {
    panel.hidden = false;
    fab.hidden = true;
    fab.setAttribute('aria-expanded', 'true');
    if (!loaded) {
      loaded = true;
      try {
        const data = await api('/api/chat');
        add('bot', GREETING);
        data.messages.forEach((m) => add(m.role, m.content));
        status.textContent = data.aiEnabled ? 'Onlayn' : 'Oddiy rejim';
        status.title = data.aiEnabled ? '' : "AI kaliti ulanmagan — chat tayyor javoblar bilan ishlaydi";
      } catch {
        add('bot', GREETING);
      }
    }
    input.focus();
  }
  function close() {
    panel.hidden = true;
    fab.hidden = false;
    fab.setAttribute('aria-expanded', 'false');
    fab.focus();
  }

  async function send(text) {
    text = text.trim();
    if (!text || busy) return;
    busy = true;
    add('user', text);
    input.value = '';
    const typing = add('bot', 'Yozmoqda…');
    typing.classList.add('typing');
    try {
      const r = await api('/api/chat', { method: 'POST', body: { message: text } });
      typing.classList.remove('typing');
      typing.textContent = r.answer;
      status.textContent = r.source === 'ai' ? 'Onlayn' : 'Oddiy rejim';
    } catch (err) {
      typing.classList.remove('typing');
      typing.textContent = err.status === 401 ? 'Sessiya tugadi. Sahifani yangilab, qayta kiring.' : err.message || "Aloqa xatosi. Qayta urinib ko'ring.";
    } finally {
      busy = false;
      log.scrollTop = log.scrollHeight;
      input.focus();
    }
  }

  fab.addEventListener('click', open);
  panel.querySelector('#chat-close').addEventListener('click', close);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !panel.hidden) close(); });
  form.addEventListener('submit', (e) => { e.preventDefault(); send(input.value); });
  panel.querySelector('#chat-clear').addEventListener('click', async () => {
    if (!confirm("Suhbat tarixi o'chirilsinmi?")) return;
    try { await api('/api/chat', { method: 'DELETE' }); log.innerHTML = ''; add('bot', GREETING); } catch (err) { toast(err.message, true); }
  });
})();
