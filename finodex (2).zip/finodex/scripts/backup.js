// Ma'lumotlar bazasining zaxira nusxasi: npm run backup
const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');

const dbFile = path.join(__dirname, '..', 'data', 'finodex.db');
if (!fs.existsSync(dbFile)) {
  console.error('data/finodex.db topilmadi. Avval serverni bir marta ishga tushiring.');
  process.exit(1);
}
const dir = path.join(__dirname, '..', 'backups');
fs.mkdirSync(dir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 16);
const out = path.join(dir, `finodex-${stamp}.db`);

const db = new DatabaseSync(dbFile);
db.exec(`VACUUM INTO '${out.replace(/'/g, "''")}'`); // server ishlab turganda ham xavfsiz nusxa
db.close();
console.log('Zaxira nusxa yaratildi:', out);
