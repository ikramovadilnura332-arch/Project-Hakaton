# Finodex — kichik biznes uchun moliya direktori

Haqiqiy ishlaydigan veb-ilova: bosh sahifa, ro'yxatdan o'tish, kirish, kabinet,
kirim-chiqim, doimiy to'lovlar, CSV import va 60 kunlik kassa prognozi.

## VS Code'da ishga tushirish

1. **Node.js 22.13 yoki yangi** (24 ham mos) o'rnating: https://nodejs.org (LTS). `node -v` bilan tekshiring.
2. Papkani VS Code'da oching: `File → Open Folder → finodex`.
3. Terminal oching (`Ctrl + ` `) va yozing:

```bash
npm install
cp .env.example .env      # Windows (cmd): copy .env.example .env
npm start
```

4. Brauzerda oching: http://localhost:3000

Kod o'zgartirganda avtomatik qayta ishga tushishi uchun: `npm run dev`.

`.env` ichida `JWT_SECRET` bo'sh qolsa, tizim uni o'zi yaratib `data/secret.key` ga saqlaydi.

## Sinab ko'rish

1. `/register` da hisob yarating.
2. Kabinetda haqiqiy kirim-chiqimni kiriting yoki CSV yuklang. *Faqat rivojlanish rejimida* (`NODE_ENV=production`
   emas) bo'sh kabinetda sinov uchun "namuna ma'lumot" tugmasi ko'rinadi. Production'da u umuman yo'q
   (server ham rad etadi), ya'ni haqiqiy saytda soxta ma'lumot bo'lmaydi.
3. Yoki o'zingizniki: "Yangi yozuv", "Doimiy to'lovlar" yoki "CSV yuklash".

CSV format (`sana,turi,summa,toifa,izoh`), `turi` — `kirim` yoki `chiqim`. Sana `2026-09-01` yoki `01.09.2026`.

## Tuzilma

```
server.js        Express server, API, autentifikatsiya
extras.js        AI chat va bildirishnomalar (backend)
scripts/backup.js  Bazaning zaxira nusxasi (npm run backup)
db.js            SQLite (data/finodex.db, Node'ning o'rnatilgan node:sqlite moduli — kompilyatsiya kerak emas)
forecast.js      Prognoz mexanizmi (asosiy "aql")
public/
  index.html     Bosh sahifa (landing)
  register.html, login.html, dashboard.html, 404.html
  css/style.css
  js/            common.js, auth.js, dashboard.js, chart.js, landing.js, notify.js, chat.js
```

## Prognoz qanday hisoblanadi (forecast.js)

- Oxirgi 8 hafta kirimidan hafta kunlari bo'yicha o'rtacha kunlik tushum olinadi.
- Oxirgi 4 hafta oldingi 4 hafta bilan taqqoslanib, yumshatilgan trend qo'llanadi (6 haftalik ma'lumot kerak).
- O'zgaruvchan xarajatlar o'rtacha kunlik qiymat bilan olinadi.
- Ijara, ish haqi, soliq, kredit **"Doimiy to'lovlar"** ro'yxatidan aniq sanasi bilan qo'shiladi.
- Qoldiq kunma-kun hisoblanadi; nolga tushadigan birinchi kun sabab bilan ogohlantiriladi.

Hozircha **mavsumiylik (masalan, fevralda 20% pasayish)** hisobga olinmaydi — buning uchun kamida 12 oylik
ma'lumot kerak. Bu keyingi qadam.

## Xavfsizlik

Parollar bcrypt bilan, sessiya httpOnly cookie ichidagi JWT bilan, kirish/ro'yxatdan o'tishda urinishlar cheklangan,
`helmet` (CSP), barcha SQL so'rovlar parametrlangan, har bir foydalanuvchi faqat o'z ma'lumotini ko'radi.

## Internetga chiqarish (production)

- `.env`: `NODE_ENV=production`, uzun tasodifiy `JWT_SECRET`.
- HTTPS bo'lishi shart (Render, Railway, Fly.io yoki o'z VPS + Nginx/Caddy).
- SQLite fayli `data/` ichida — hosting'da **doimiy disk (volume)** ulang, aks holda qayta deploy'da ma'lumot yo'qoladi.
- Katta yuklama yoki bir nechta server kerak bo'lsa, PostgreSQL'ga o'ting.

## Hali qilinmagan (haqiqiy mahsulot uchun keyingi qadamlar)

1. **To'lov** ($25/oy): Payme / Click / Uzum integratsiyasi. Hozir faqat 7 kunlik sinov hisoblanadi, cheklov yo'q.
2. **Bank / onlayn-kassa / soliq ma'lumotini avtomatik o'qish**: bank API shartnomalari va ruxsatlari kerak;
   hozir qo'lda va CSV orqali.
3. Email tasdiqlash (ro'yxatdan o'tganda).
4. Telegram/SMS orqali ogohlantirish yuborish.
5. Mavsumiylik va aniqroq prognoz modeli.


## Ma'lumotlar bazasi (SQLite)

Alohida o'rnatish **kerak emas**. Server birinchi ishga tushganda `data/finodex.db` faylini o'zi yaratadi
va barcha jadvallarni ochadi (Node.js ichidagi `node:sqlite`). Bazani ko'rish uchun VS Code'da
"SQLite Viewer" kengaytmasini o'rnating va `data/finodex.db` ni oching.

- **Zaxira nusxa:** `npm run backup` → `backups/finodex-SANA.db` (server ishlab turganda ham xavfsiz).
  Serverda buni `cron` orqali kuniga bir marta ishlating va nusxani boshqa joyga (masalan, boshqa server yoki bulut) ko'chiring.
- **Hostingda:** `data/` papkasi **doimiy diskda** turishi shart. Render/Railway/Fly.io da "Persistent Disk / Volume" ulab,
  uni `data/` ga mounting qiling. Oddiy VPS da esa fayl shundoq qoladi.
- **O'sganda:** bir nechta server yoki juda ko'p foydalanuvchi bo'lsa, PostgreSQL'ga o'ting (Neon, Supabase yoki o'z serveringiz).
- **Qonun:** O'zbekiston fuqarolarining shaxsiy ma'lumotlari, amaldagi talabga ko'ra, mamlakat ichidagi serverlarda saqlanishi
  kerak. Ommaviy ishga tushirishdan oldin serveringiz joylashuvini va ro'yxatga olish talablarini yurist bilan tekshiring.

## AI chat

Kabinetning pastki o'ng burchagida "AI yordamchi" tugmasi bor. Chat foydalanuvchining o'z prognozi, qoldig'i va
xarajatlari asosida javob beradi. Har doim javob beradi: AI ulanmagan yoki ishlamay qolsa, avtomatik (tayyor)
javoblarga o'tadi.

AI'ni yoqish: https://console.anthropic.com dan API kalit oling va `.env` ga yozing:

```
ANTHROPIC_API_KEY=sk-ant-...
```

Diqqat: AI yoqilganda foydalanuvchining moliyaviy xulosasi (qoldiq, prognoz, toifalar) Anthropic API'ga yuboriladi.
Foydalanuvchilarga bu haqda maxfiylik siyosatida yozing.

## Bildirishnomalar

Prognoz yangi xavf topsa (kassa uzilishi, savdo pasayishi, xarajat oshishi), kassa uzilishi sanasi 3+ kunga siljisa
yoki xavf yo'qolsa, kabinetdagi qo'ng'iroqcha orqali bildirishnoma keladi. Foydalanuvchi ruxsat bersa, brauzerning o'z
bildirishnomasi ham chiqadi. Server har 30 daqiqada barcha foydalanuvchilarni tekshiradi. Sahifa yopiq bo'lsa
bildirishnoma keyingi kirishda ko'rinadi; yopiq holatda yuborish uchun Telegram/SMS/email kerak (keyingi qadam).

## Sinov muddati

Yangi foydalanuvchiga 7 kun beriladi (`server.js`, ro'yxatdan o'tish qismida).


## Klaviatura

- **Enter** — keyingi maydonga o'tadi; oxirgi maydonda formani yuboradi ("Kirish", "Hisob yaratish", "Yozuvni qo'shish"...).
- **Shift + Enter** — oldingi maydonga qaytadi.
- Yozuv qo'shilgach, kursor yana "Summa" maydoniga qaytadi — ketma-ket kiritish uchun.
- Parol maydonlarida ko'z tugmasi (parolni ko'rsatish/yashirish) va Caps Lock ogohlantirishi bor.
- Chatda Enter — xabarni yuboradi, Esc — yopadi.

## Parolni tiklash (email orqali)

"Parolni unutdingizmi?" → email → 1 soat amal qiladigan bir martalik havola → yangi parol. Havola bazada faqat
xesh ko'rinishida saqlanadi; parol o'zgargach eski sessiyalar avtomatik yopiladi.

Haqiqiy email yuborish uchun `.env` ga SMTP sozlang (istalgan SMTP: Gmail App Password, Mailgun, SendGrid, Brevo, o'z serveringiz):

```
APP_URL=https://sizning-domen.uz
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=...
SMTP_PASS=...
SMTP_FROM=Finodex <no-reply@sizning-domen.uz>
```

- Rivojlanish rejimida SMTP bo'lmasa, havola **server terminalida** chiqadi (Ctrl+klik bilan oching).
- Production'da `APP_URL` va SMTP bo'lmasa, sayt buni yashirmaydi: foydalanuvchiga "sozlanmagan" xabari chiqadi.
